import React from 'react'

function root() {
  return (
    <div>
    <h1>hello megha </h1>
    </div>
  )
}

export default root