import React from 'react'
import ReCAPTCHA from "react-google-recaptcha";
import CreateCaptcha from './CreateCaptcha';


function LoginPage() {
    // const CaprchaValue = (value) => {
        // console.log("Captcha value:", value);

    // }
  return (
    <div>
    <div><div>
    <h1>LogIn/SineIn</h1>
    <div>
    <CreateCaptcha/>
    </div>
    
    </div>
    </div>
    </div>
  )
}

export default LoginPage