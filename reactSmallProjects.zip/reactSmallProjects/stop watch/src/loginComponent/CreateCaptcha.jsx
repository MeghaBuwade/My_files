import React, {useState} from 'react';


const generateCode =(n)=>{
    return Math.floor(Math.random() * (9 * Math.pow(10, n - 1))) + Math.pow(10, n - 1);
}
const randomCode = generateCode(4);
console.log('Random Code:', randomCode);

function CreateCaptcha() {

  return (
    <div>{randomCode}</div>
  )
}

export default CreateCaptcha