import React from 'react'
import root from './root'

function root2() {
  return (
    <div>
    <h2>hello</h2>
    </div>
  )
}

export default root2