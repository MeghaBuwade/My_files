import {useState, useEffect} from 'react'
import LoginPage from './loginComponent/LoginPage';




function App() {
  // const [dataAll, setDataAll] = useState([]);
  // useEffect(() =>{
  //   fetch('https://jsonplaceholder.typicode.com/todos')
  //   .then((res)=>{
  //     return res.json();

  //   })
  //   .then((data) => {
  //     console.log(data);
  //     setDataAll(data);
  //   });
  // },[]);
  return (

    <div>
    <LoginPage/>
    
    </div>
  )
}

export default App
// <div>
//     <LoginPage/>
//     {dataAll.map((todo)=>(
//       <div key = {todo.id}>
//       <h3>{todo.id}</h3>
//       <h2>{todo.userId}</h2>
//       <h5>{todo.title}</h5>
//       <h6 style={{color: "red"}}>{todo.completed ? <button style={{background:"green"}}></button>:<button style={{background:"red"}}></button>}</h6>

//       </div>
      
//     ))}</div>
//   )
// }

//https://jsonplaceholder.typicode.com/todos