import React from "react";
import"./DogList.css";

const Dog = (props) => {

    return (
        <div className="child">
            <img className="size" src={props.url}/>

        </div>
    )
}



export default Dog;