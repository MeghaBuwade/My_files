import React from 'react'

function FileRouterA() {
  return (
    <div>about</div>
  )
}

export default FileRouterA
