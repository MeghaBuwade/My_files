function MyComponent({name}){
    return <div>Hello,{name}!</div>
}
// React is a dicletive
// bun -v
//  pnpm -v
// npm i -g pnpm
// npm i -g bun
// pnpm create vite
// pnpm i
// pnpm run dev
// 
