import logo from './logo.svg';
import './App.css';
import MockTask from './MockTask.jsx'
// import UseStatefun from './HooksCpmponrnt/useState';
// import UseEff from './HooksCpmponrnt/useEffect';
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import FileRouterA from "./RouterComponent/FileRouterA.jsx";

function App() {
  return (
    <div className="App">
     <MockTask />
    </div>
  );
}

export default App;
// <UseStatefun />
// <UseEff />
// <FileRouterA />
// <Routes>
//   <Route path='/' element={<FileRouterA />} />
// </Routes>