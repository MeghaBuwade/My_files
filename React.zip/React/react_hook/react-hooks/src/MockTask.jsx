import React, {useState, useEffect} from 'react'

function MockTask() {
    const [number, setNumber] = useState(0);
    // const [decrement, setDecrement] = useState(0);

   const incrementfun = () =>{
    setNumber(number + 1)
   }
   const decrementfun = () =>{
    if(number>0){
        setNumber(number - 1)

    }
   }
  return (
    <div>
    <h1>Counter</h1>
    <p>{number}</p>
    <button onClick={incrementfun}>+</button>
    <button onClick={decrementfun}>-</button>
    <p>Hello megha</p>
    <button>show</button>


    </div>
  )
}

export default MockTask