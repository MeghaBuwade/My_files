import React, {useEffect, useState} from 'react'


function UseEff() {
    const [count, setCount] = useState(0);
    useEffect(() => {
        document.title = `${count} new messages!`;
    
    }, [count]);

  return (
    <div>UseEff
    <h3>count : {count} </h3>
    <button onClick={() => setCount(count + 5)}>##</button>
    </div>
  )
}

export default UseEff