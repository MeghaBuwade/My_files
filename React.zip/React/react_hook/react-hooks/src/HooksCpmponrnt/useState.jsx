import React, { useState } from 'react';

function UseStatefun() {
    const [count, setCount] = useState(0);
    const [name, setName] = useState("");

    function increaseCounter() {
        setCount(count + 1);
    };
    function dicreament(){
        setCount(count - 1);
    }
    
    return (
        <div>
            <h1>useState</h1>
            <input type='text' onChange={(e) => setName(e.target.value)}/>
            <h2>{name} Counter: {count}</h2>
            <button onClick={increaseCounter}>Increase</button>
            <button onClick={dicreament}>decrease</button>

        </div>
    );
}

export default UseStatefun;
