// app.module.ts
import { Module } from '@nestjs/common';
import { ESignController } from './e-sign/e-sign.controller';
import { HelloSignService } from './hello-sign/hello-sign.service';

@Module({
  imports: [],
  controllers: [ESignController],
  providers: [HelloSignService],
})
export class AppModule {}
