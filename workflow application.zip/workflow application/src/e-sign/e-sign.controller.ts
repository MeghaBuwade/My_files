// e-sign.controller.ts
import { Controller, Post, Body } from '@nestjs/common';
import { HelloSignService } from './hello-sign.service';

@Controller('e-sign')
export class ESignController {
  constructor(private readonly helloSignService: HelloSignService) {}

  @Post('request')
  async createSignatureRequest(
    @Body('documentUrl') documentUrl: string,
    @Body('signers') signers: { email: string; name: string }[],
  ) {
    const signerEmails = await this.helloSignService.createSignatureRequest(documentUrl, signers);
    return { signerEmails };
  }
}
