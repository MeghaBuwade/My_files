import { Test, TestingModule } from '@nestjs/testing';
import { ESignController } from './e-sign.controller';

describe('ESignController', () => {
  let controller: ESignController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ESignController],
    }).compile();

    controller = module.get<ESignController>(ESignController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
