// hello-sign.service.ts
import { Injectable } from '@nestjs/common';
import { HelloSign } from 'hello-sign';

@Injectable()
export class HelloSignService {
  private readonly client: HelloSign;

  constructor() {
    this.client = new HelloSign({ apiKey: 'YOUR_HELLOSIGN_API_KEY' });
  }

  async createSignatureRequest(documentUrl: string, signers: { email: string; name: string }[]) {
    const options = {
      test_mode: 1, // Change to 0 for production
      title: 'Document Title',
      subject: 'Please sign this document',
      message: 'Hi, please sign this document.',
      signers: signers.map(signer => ({
        email_address: signer.email,
        name: signer.name,
      })),
      files: [documentUrl],
    };

    try {
      const response = await this.client.signatureRequest.createEmbedded(options);
      return response.signature_request.signatures.map(signature => signature.signer_email_address);
    } catch (error) {
      console.error('Error creating signature request:', error);
      throw error;
    }
  }
}
