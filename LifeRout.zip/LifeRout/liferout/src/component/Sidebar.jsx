// import React, { useState } from 'react';

function Sidebar() {

  return (
    <div>
      <h1>LifeRout</h1>
      <div>
      <button>Dashboard</button>
      <button>Routine</button>
      <button>Settings</button>
      </div>
    
    
    </div>
  );
}

export default Sidebar;