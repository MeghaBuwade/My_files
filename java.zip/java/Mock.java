//[2 3 4 6 5 7 8]
class mock{
    public static void main(int arr[],int a){
        int arr = [2 3 4 6 5 7 8];
        int n = arr.length;
        for(int i = 0; i<n; i++){
            if(arr[i] == a)
            return a;

          //System.out.println()
        }
        return -1;
    }
    // public static void main(String args[]){
    //     int arr[]={2 3 4 6 5 7 8};
    //     int a = 6;
    //     int result = search (arr.a);
    //     if(result == -1)
    //     System.out.println("element");
    //}
}

