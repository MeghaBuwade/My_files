class Dsa{
    public static void main (String[] args){
         int arr [] = {1,2,3,4,5,7};
        // int n = arr.length;
        // int sum =0;
        // for(int i =0; i<n; i++){
        //     if(arr[i]%2 == 0){
        //        sum += arr[i];
        //     }
        // }
        // System.out.print("Sum of all even numbers : " + sum);

    //    int x, low, high;
    //    while(low<=high){
    //     int mid = low + (high-low)/2;
    //     if(arr[mid]==x){
    //         return mid;
    //     }
        
    //     if(arr[mid] < x){
    //         low = mid + 1;
    //     }
       
    //     else {
    //         high = mid -1;
    //     }
    //     return -1
    //    }

    //    System.out.print()


//Merge Sort

    int start, mid, end;
    int merge[] = new int[end-start+1];
    int index1= start;
    int index2= mid +1;
    int x=0;
    while(index1<= mid && index2 <= end){
        if(arr[index1]<= arr[index2]){
            merge[x++]= arr[index1++];
        }else{
            merge[x++]=arr[index2++];
        }
    }
    while(index1 <= mid){
        merge[x++] = arr[index1++];


    }
    while(index2 <= end){
        merge[x++] = arr[index2++];
        

    }
    for(int i =0, j = start; i<merge.length; i++, j++){
        arr[j] = merge[i];
    }

    }
}

