from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import json
import os
import logging
import time
import schedule

# Configuration
TARGET_WEBSITES = [
    'https://www.unlimited4x4.com/vehicles-for-sale'  # Adjust URL as needed
]
JSON_FILE = 'vehicle_data.json'
LOG_FILE = 'scraping_errors.log'

# Setup logging
logging.basicConfig(filename=LOG_FILE, level=logging.ERROR)

# Setup WebDriver
chrome_options = Options()
chrome_options.add_argument("--headless")  # Run in headless mode (no GUI)
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

# Path to your chromedriver executable
chrome_driver_path = 'path/to/chromedriver'  # Update this path

webdriver_service = Service(chrome_driver_path)
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

def load_existing_data():
    """Load previously collected data from the JSON file."""
    if os.path.exists(JSON_FILE):
        with open(JSON_FILE, 'r') as file:
            return json.load(file)
    return []

def save_data(new_data):
    """Append new data to the JSON file."""
    existing_data = load_existing_data()
    combined_data = existing_data + new_data
    # Ensure uniqueness based on VIN
    unique_data = {item['vin']: item for item in combined_data}.values()
    with open(JSON_FILE, 'w') as file:
        json.dump(list(unique_data), file, indent=4)

def scrape_data(url):
    """Scrape vehicle data from a single website using Selenium."""
    try:
        driver.get(url)
        time.sleep(5)  # Wait for JavaScript to load content (adjust as needed)

        # Example selectors (adjust based on actual site structure)
        vehicles = driver.find_elements(By.CSS_SELECTOR, '.vehicle-item')  # Adjust the selector
        data = []
        for vehicle in vehicles:
            try:
                vin = vehicle.find_element(By.CSS_SELECTOR, '.vin-class').text.strip()  # Adjust the selector
                make = vehicle.find_element(By.CSS_SELECTOR, '.make-class').text.strip()  # Adjust the selector
                model = vehicle.find_element(By.CSS_SELECTOR, '.model-class').text.strip()  # Adjust the selector
                year = vehicle.find_element(By.CSS_SELECTOR, '.year-class').text.strip()  # Adjust the selector
                price = vehicle.find_element(By.CSS_SELECTOR, '.price-class').text.strip()  # Adjust the selector
                dealership = vehicle.find_element(By.CSS_SELECTOR, '.dealership-class').text.strip()  # Adjust the selector
                
                data.append({
                    'vin': vin,
                    'make': make,
                    'model': model,
                    'year': year,
                    'price': price,
                    'dealership': dealership
                })
            except Exception as inner_e:
                logging.error(f"Error extracting data from vehicle element: {inner_e}")
        return data
    except Exception as e:
        logging.error(f"Error scraping {url}: {e}")
        return []

def filter_new_data(new_data, existing_data):
    """Filter out data that already exists in the JSON file."""
    existing_vins = {item['vin'] for item in existing_data}
    return [item for item in new_data if item['vin'] not in existing_vins]

def scrape_and_update():
    """Main function to scrape data and update the JSON file."""
    all_new_data = []
    for url in TARGET_WEBSITES:
        new_data = scrape_data(url)
        all_new_data.extend(new_data)

    existing_data = load_existing_data()
    new_entries = filter_new_data(all_new_data, existing_data)
    
    if new_entries:
        save_data(new_entries)
        print(f"Added {len(new_entries)} new entries.")
    else:
        print("No new entries found.")

def schedule_scraping():
    """Schedule the scraping process at regular intervals."""
    schedule.every().day.at("00:00").do(scrape_and_update)  # Adjust the time as needed

    while True:
        schedule.run_pending()
        time.sleep(60)  # Wait one minute before checking again

if __name__ == "__main__":
    try:
        schedule_scraping()
    finally:
        driver.quit()  # Ensure the browser is closed properly
