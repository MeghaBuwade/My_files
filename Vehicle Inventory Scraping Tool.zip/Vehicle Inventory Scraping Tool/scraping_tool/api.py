from selenium import webdriver
driver = webdriver.Firefox()
driver.get("https://www.unlimited4x4.com/")