import requests
from bs4 import BeautifulSoup
import json
import os
import logging
import time
import schedule

# Configuration
TARGET_WEBSITES = [
    'https://www.unlimited4x4.com'
 
]
JSON_FILE = 'vehicle_data.json'
LOG_FILE = 'scraping_errors.log'

# Setup logging
logging.basicConfig(filename=LOG_FILE, level=logging.ERROR)

def load_existing_data():
    """Load previously collected data from the JSON file."""
    if os.path.exists(JSON_FILE):
        with open(JSON_FILE, 'r') as file:
            return json.load(file)
    return []

def save_data(new_data):
    """Append new data to the JSON file."""
    existing_data = load_existing_data()
    combined_data = existing_data + new_data
    # Ensure uniqueness based on VIN
    unique_data = {item['vin']: item for item in combined_data}.values()
    with open(JSON_FILE, 'w') as file:
        json.dump(list(unique_data), file, indent=4)

def scrape_data(url):
    """Scrape vehicle data from a single website."""
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check for request errors
        soup = BeautifulSoup(response.text, 'html.parser')

        # Replace these selectors with the actual ones from your target websites
        vehicles = soup.select('.vehicle-listing')
        data = []
        for vehicle in vehicles:
            vin = vehicle.select_one('.vin').text.strip()
            make = vehicle.select_one('.make').text.strip()
            model = vehicle.select_one('.model').text.strip()
            year = vehicle.select_one('.year').text.strip()
            price = vehicle.select_one('.price').text.strip()
            dealership = vehicle.select_one('.dealership').text.strip()
            
            data.append({
                'vin': vin,
                'make': make,
                'model': model,
                'year': year,
                'price': price,
                'dealership': dealership
            })
        return data
    except requests.RequestException as e:
        logging.error(f"Error scraping {url}: {e}")
        return []

def filter_new_data(new_data, existing_data):
    """Filter out data that already exists in the JSON file."""
    existing_vins = {item['vin'] for item in existing_data}
    return [item for item in new_data if item['vin'] not in existing_vins]

def scrape_and_update():
    """Main function to scrape data and update the JSON file."""
    all_new_data = []
    for url in TARGET_WEBSITES:
        new_data = scrape_data(url)
        all_new_data.extend(new_data)

    existing_data = load_existing_data()
    new_entries = filter_new_data(all_new_data, existing_data)
    
    if new_entries:
        save_data(new_entries)
        print(f"Added {len(new_entries)} new entries.")
    else:
        print("No new entries found.")

def schedule_scraping():
    """Schedule the scraping process at regular intervals."""
    schedule.every().day.at("00:00").do(scrape_and_update)  # Adjust the time as needed

    while True:
        schedule.run_pending()
        time.sleep(60)  # Wait one minute before checking again

if __name__ == "__main__":
    schedule_scraping()
