// models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  contact: String,
  age: Number,
  address: String
});

const User = mongoose.model('User', userSchema);

module.exports = User;
