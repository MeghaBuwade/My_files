// index.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const User = require('./models/User');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB (replace 'mongodb://localhost:27017/your_database' with your MongoDB connection string)
mongoose.connect('mongodb://localhost:27017/user_fromData', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(error => {
  console.error('Error connecting to MongoDB:', error);
});

// POST endpoint to add a new user
app.post('/api/users', async (req, res) => {
  try {
    const newUser = new User(req.body);
    await newUser.save();
    res.json(newUser);
  } catch (error) {
    console.error('Error adding user:', error);
    res.status(500).json({ error: 'Failed to add user' });
  }
});

// GET endpoint to retrieve all users
app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});











// const express = require('express');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 5000;

// // Array to store user data
// let users = [];

// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// app.post('/users', (req, res) => {
//   try {
//     const { name, email, contact, age, address } = req.body;
//     const newUser = { id: users.length + 1, name, email, contact, age, address };
//     users.push(newUser);
//     res.json({ message: 'User created successfully', user: newUser });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// app.get('/users', (req, res) => {
//   try {
//     res.json(users);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// app.put('/users/:id', (req, res) => {
//   try {
//     const { id } = req.params;
//     const { name, email, contact, age, address } = req.body;
//     const userIndex = users.findIndex(user => user.id === parseInt(id));
//     if (userIndex !== -1) {
//       users[userIndex] = { ...users[userIndex], name, email, contact, age, address };
//       res.json({ message: 'User updated successfully', updatedUser: users[userIndex] });
//     } else {
//       res.status(404).json({ message: 'User not found' });
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// app.delete('/users/:id', (req, res) => {
//   try {
//     const { id } = req.params;
//     const initialLength = users.length;
//     users = users.filter(user => user.id !== parseInt(id));
//     if (users.length < initialLength) {
//       res.json({ message: 'User deleted successfully' });
//     } else {
//       res.status(404).json({ message: 'User not found' });
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');

// const app = express();
// const PORT = process.env.PORT || 5000;

// app.use(bodyParser.json());
// app.use(cors());

// // Dummy database to store users
// let users = [];

// // POST endpoint to add a new user
// app.post('/api/users', (req, res) => {
//   const newUser = req.body;
//   users.push(newUser);
//   res.json(newUser);
// });

// // GET endpoint to retrieve all users
// app.get('/api/users', (req, res) => {
//   res.json(users);
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);

// });

// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");
// const mongoose = require("mongoose");
// // const app = express();
// const User = require("./models/User");

// const app = express();
// const PORT = process.env.PORT || 4000;

// app.use(bodyParser.json());
// app.use(cors());
// mongoose.connect("mongodb://localhost:27017/user_fromData", {
//   useNewUrlParser: true,
// });

// // Dummy database to store users
// // let users = [];

// // POST endpoint to add a new user
// app.post("/api/users", async (req, res) => {
//   //   const newUser = req.body;
//   //   users.push(newUser);
//   //   res.json(newUser);
//   const FullName = req.body.fullName;
//   const Email = req.body.email;
//   const Contect = req.body.Contect;
//   const Age = req.body.age;
//   const Address = req.body.address;

//   const formData = new User({
//     name: FullName,
//     email: Email,
//     contact: Contect,
//     age: Age,
//     address: Address,
//   });
//   try {
//     await formData.save();
//     res.send("inserted data..");
//   } catch (err) {
//     console.log(err);
//   }
// });

// // GET endpoint to retrieve all users
// app.get("/api/users", (req, res) => {
//   res.json(users);
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
// });

// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");

// const app = express();
// const PORT = process.env.PORT || 4000;

// app.use(bodyParser.json());
// app.use(cors());

// // POST endpoint to add a new user
// app.post("/api/users", (req, res) => {
//   const fullName = req.body.name;
//   const email = req.body.email;
//   const contact = req.body.contact;
//   const age = req.body.age;
//   const address = req.body.address;

//   // Here you can process the received data as you like,
//   // for example, you could log it or respond with a message.
//   console.log("Received user data:", { fullName, email, contact, age, address });
//   res.send("Received user data successfully.");
// });

// // GET endpoint to retrieve all users (dummy implementation)
// app.get("/api/users", (req, res) => {
//   // Dummy response, as we are not storing users
//   res.json({ message: "No users stored as this is a dummy implementation." });
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
// });

// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");
// const mongoose = require("mongoose");

// const app = express();
// const PORT = process.env.PORT || 4000;

// app.use(bodyParser.json());
// app.use(cors());

// mongoose.connect("mongodb://localhost:27017/user_fromData", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// const userSchema = new mongoose.Schema({
//   name: String,
//   email: String,
//   contact: String,
//   age: Number,
//   address: String,
// });

// const User = mongoose.model("User", userSchema);

// app.post("/api/users", async (req, res) => {
//   const { name, email, contact, age, address } = req.body;

//   try {
//     const newUser = new User({
//       name,
//       email,
//       contact,
//       age,
//       address,
//     });

//     await newUser.save();
//     res.status(201).send("User created successfully.");
//   } catch (error) {
//     console.error("Error creating user:", error);
//     res.status(500).send("Internal Server Error");
//   }
// });

// app.get("/api/users", async (req, res) => {
//   try {
//     const users = await User.find();
//     res.json(users);
//   } catch (error) {
//     console.error("Error retrieving users:", error);
//     res.status(500).send("Internal Server Error");
//   }
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
// });