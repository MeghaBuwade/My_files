const express = require("express");
const server = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
server.use(bodyParser.json());

main().catch((err) => console.log(err));

async function main() {
  await mongoose.connect("mongodb://127.0.0.1:27017/test");
  console.log("Connected to MongoDB!");
}

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  contact: String,
  age: Number,
  address: String,
});

const User = mongoose.model("User", userSchema);

server.use(cors());
server.use(bodyParser.json());

server.post("/demo", async (req, res) => {
  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email,
      contact: req.body.contact,
      age: req.body.age,
      address: req.body.address,
    });

    const savedUser = await user.save();
    console.log("User created:", savedUser);
    res.json(savedUser);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Could not create user" });
  }
});

server.get("/allusers", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    console.error("Error fetching users:", err);
    res.status(500).json({ error: "Could not fetch users" });
  }
});

// server.delete('/contact/:id', (req, res, next) => {
//   User.deleteOne({ _id: req.params.id }, function(err, result) {
//     if (err) {
//       console.error("Error deleting user:", err);
//       res.status(500).json({ error: "Could not delete user" });
//     } else {
//       console.log("User deleted:", result);
//       res.json(result);
//     }
//   });
// });


// server.delete('/contact/:id', (req, res, next) => {
//   contact.deleteOne({ _id: new objectID(req.params._id) }, function(err, result) {
//     if (err) {
//       res.json(err);
//     } else {
//       res.json(result);
//     }
//   });
// });

server.listen(8080, () => {
  console.log("Server started on port 8080");
});
