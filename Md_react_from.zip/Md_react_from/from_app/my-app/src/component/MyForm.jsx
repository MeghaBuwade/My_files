import React, { useState } from "react";
import "./Style.css";
import { useHistory } from 'react-router-dom';

const MyForm = () => {
  const history = useHistory();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    contact: "",
    age: "",
    address: "",
  });
  const [submittedData, setSubmittedData] = useState([]);
  const [loading, setLoading] = useState(false); 
  const [error, setError] = useState(null); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8080/demo", {
        method: "POST",
        body: JSON.stringify(formData),
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        throw new Error('Failed to add user');
      }
      const data = await response.json();
      console.log(data);
      setSubmittedData([...submittedData, formData]);
      setFormData({
        name: "",
        email: "",
        contact: "",
        age: "",
        address: "",
      });
      setLoading(false);
    } catch (error) {
      setError('Failed to add user');
      setLoading(false);
    }
  };

  const handleUserListClick = async () => {
    try {
      const response = await fetch("http://localhost:8080/allusers");
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      const users = await response.json();
      history.push('/userlist');
      console.log(users);
    } catch (error) {
      setError('Failed to fetch users');
      console.error("Error fetching users:", error);
    }
  };

  return (
    <div className="form-container">
      <h2 className="form-heading">Add New User</h2>
      <form onSubmit={handleSubmit}>
        <label className="form-label">
          Name:
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="form-input"
          />
        </label>
        <label className="form-label">
        Email:
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className="form-input"
        />
      </label>
      <label className="form-label">
        Contact:
        <input
          type="text"
          name="contact"
          value={formData.contact}
          onChange={handleChange}
          className="form-input"
        />
      </label>
      <label className="form-label">
        Age:
        <input
          type="number"
          name="age"
          value={formData.age}
          onChange={handleChange}
          className="form-input"
        />
      </label>
      <label className="form-label">
        Address:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
          className="form-input"
        />
      </label>{" "}        <button type="submit" className="submit-button" disabled={loading}>
          {loading ? 'Adding...' : 'Submit'}
        </button>
      </form>
      {error && <p className="error-message">{error}</p>}
      <button
        type="button"
        className="submit-button"
        onClick={handleUserListClick}
        disabled={loading}
      >
        {loading ? 'Fetching...' : 'User List'}
      </button>
    </div>
  );
};

export default MyForm;
