import React, { useState, useEffect } from "react";
import "./StyleS.css";
import { useHistory } from "react-router-dom";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [editingUser, setEditingUser] = useState(null);
  const [editedUser, setEditedUser] = useState({
    name: "",
    email: "",
    contact: "",
    age: "",
    address: "",
  });
  const history = useHistory();

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch("http://localhost:8080/allusers");
        if (!response.ok) {
          throw new Error("Failed to fetch users");
        }
        const userData = await response.json();
        setUsers(userData);
        setLoading(false);
      } catch (error) {
        setError("Failed to fetch users");
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const inputHandler = (e) => {
    setSearch(e.target.value.toLowerCase());
  };

  const handleGoToFirstPage = () => {
    history.push("/");
  };

  const handleSearchClick = () => {
    const filteredUsers = users.filter((user) =>
      user.name.toLowerCase().includes(search)
    );
    setUsers(filteredUsers);
  };
  const handleEditUser = (user) => {
    setEditingUser(user);
    setEditedUser({
      name: user.name,
      email: user.email,
      contact: user.contact,
      age: user.age,
      address: user.address,
    });
  };

  const handleEditInputChange = (e) => {
    const { name, value } = e.target;
    setEditedUser((prevUser) => ({
      ...prevUser,
      [name]: value,
    }));
  };
  const handleSubmitEditUser = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        `http://localhost:8080/updateuser/${editingUser.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(editedUser),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update user");
      }
      const updatedUser = await response.json();
      const updatedUsers = users.map((user) =>
        user.id === updatedUser.id ? updatedUser : user
      );
      setUsers(updatedUsers);
      setEditingUser(null);
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleCancelEditUser = () => {
    setEditingUser(null);
  };

  const handleRemoveUser = (index) => {
    const updatedUsers = [...users];
    updatedUsers.splice(index, 1);
    setUsers(updatedUsers);
  };

  return (
    <div>
      <button onClick={handleGoToFirstPage} className="addData">
        Add
      </button>
      <input
        placeholder="Search"
        onChange={inputHandler}
        className="search-input"
      />
      <button type="submit" className="btn" onClick={handleSearchClick}>
        Search
      </button>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : users.length === 0 ? (
        <p>No users available.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Contact</th>
              <th>Age</th>
              <th>Address</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={index}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.contact}</td>
                <td>{user.age}</td>
                <td>{user.address}</td>
                <td>
                  <button
                    className="edit-button"
                    onClick={() => handleEditUser(user)}
                  >
                    Edit
                  </button>
                  <button
                    className="remove-button"
                    onClick={() => handleRemoveUser(index)}
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {editingUser && (
        <div className="popup-container">
          <div className="popup">
            <form onSubmit={handleSubmitEditUser}>
              <input
                type="text"
                placeholder="Name"
                name="name"
                value={editedUser.name}
                onChange={handleEditInputChange}
              />
              <input
                type="text"
                placeholder="Email"
                name="email"
                value={editedUser.email}
                onChange={handleEditInputChange}
              />
              <input
                type="text"
                placeholder="Contact"
                name="contact"
                value={editedUser.contact}
                onChange={handleEditInputChange}
              />
              <input
                type="text"
                placeholder="Age"
                name="age"
                value={editedUser.age}
                onChange={handleEditInputChange}
              />
              <input
                type="text"
                placeholder="Address"
                name="address"
                value={editedUser.address}
                onChange={handleEditInputChange}
              />
              <div className="popup-buttons">
                <button type="submit">Save Changes</button>
                <button onClick={handleCancelEditUser}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserList;

// import React, { useState, useEffect } from "react";
// import "./StyleS.css";
// import { useHistory } from "react-router-dom";

// const UserList = () => {
//   const [users, setUsers] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [search, setSearch] = useState("");
//   const [editingUser, setEditingUser] = useState(null);
//   const [editedUser, setEditedUser] = useState({
//     name: "",
//     email: "",
//     contact: "",
//     age: "",
//     address: ""
//   });
//   const history = useHistory();

//   useEffect(() => {
//     const fetchUsers = async () => {
//       try {
//         const response = await fetch("http://localhost:8080/allusers");
//         if (!response.ok) {
//           throw new Error("Failed to fetch users");
//         }
//         const userData = await response.json();
//         setUsers(userData);
//         setLoading(false);
//       } catch (error) {
//         setError("Failed to fetch users");
//         setLoading(false);
//       }
//     };

//     fetchUsers();
//   }, []);

//   const inputHandler = (e) => {
//     setSearch(e.target.value.toLowerCase());
//   };

//   const handleGoToFirstPage = () => {
//     history.push("/");
//   };

//   const handleSearchClick = () => {
//     const filteredUsers = users.filter((user) =>
//       user.name.toLowerCase().includes(search)
//     );
//     setUsers(filteredUsers);
//   };

//   const handleEditUser = (user) => {
//     setEditingUser(user);
//     setEditedUser({
//       name: user.name,
//       email: user.email,
//       contact: user.contact,
//       age: user.age,
//       address: user.address
//     });
//   };

//   const handleEditInputChange = (e) => {
//     const { name, value } = e.target;
//     setEditedUser((prevUser) => ({
//       ...prevUser,
//       [name]: value
//     }));
//   };

//   const handleSubmitEditUser = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch(`http://localhost:8080/updateuser/${editingUser.id}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json"
//         },
//         body: JSON.stringify(editedUser)
//       });
//       if (!response.ok) {
//         throw new Error("Failed to update user");
//       }
//       const updatedUser = await response.json();
//       const updatedUsers = users.map(user =>
//         user.id === updatedUser.id ? updatedUser : user
//       );
//       setUsers(updatedUsers);
//       setEditingUser(null);
//     } catch (error) {
//       console.error("Error updating user:", error);
//     }
//   };

//   const handleCancelEditUser = () => {
//     setEditingUser(null);
//   };

//   return (
//     <div>
//       <button onClick={handleGoToFirstPage}>Add</button>
//       <input
//         placeholder="Search"
//         onChange={inputHandler}
//         className="search-input"
//       />
//       <button type="submit" className="btn" onClick={handleSearchClick}>
//         Search
//       </button>
//       {loading ? (
//         <p>Loading...</p>
//       ) : error ? (
//         <p>{error}</p>
//       ) : users.length === 0 ? (
//         <p>No users available.</p>
//       ) : (
//         <table>
//           <thead>
//             <tr>
//               <th>Name</th>
//               <th>Email</th>
//               <th>Contact</th>
//               <th>Age</th>
//               <th>Address</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {users.map((user, index) => (
//               <tr key={index}>
//                 <td>{user.name}</td>
//                 <td>{user.email}</td>
//                 <td>{user.contact}</td>
//                 <td>{user.age}</td>
//                 <td>{user.address}</td>
//                 <td>
//                   <button className="edit-button" onClick={() => handleEditUser(user)}>Edit</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}
//       {editingUser && (
//         <div className="popup-container">
//           <div className="popup">
//             <form onSubmit={handleSubmitEditUser}>
//               <input
//                 type="text"
//                 placeholder="Name"
//                 name="name"
//                 value={editedUser.name}
//                 onChange={handleEditInputChange}
//               />
//               <input
//                 type="text"
//                 placeholder="Email"
//                 name="email"
//                 value={editedUser.email}
//                 onChange={handleEditInputChange}
//               />
//               <input
//                 type="text"
//                 placeholder="Contact"
//                 name="contact"
//                 value={editedUser.contact}
//                 onChange={handleEditInputChange}
//               />
//               <input
//                 type="text"
//                 placeholder="Age"
//                 name="age"
//                 value={editedUser.age}
//                 onChange={handleEditInputChange}
//               />
//               <input
//                 type="text"
//                 placeholder="Address"
//                 name="address"
//                 value={editedUser.address}
//                 onChange={handleEditInputChange}
//               />
//               <div className="popup-buttons">
//                 <button type="submit">Save Changes</button>
//                 <button onClick={handleCancelEditUser}>Cancel</button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}

//     </div>
//   );
// };

// export default UserList;
