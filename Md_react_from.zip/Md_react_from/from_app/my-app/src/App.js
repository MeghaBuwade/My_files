import './App.css';
// import AddUserForm from './component/AddUserForm';
// import CreateAc from './component/CreateAc';
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import MyForm from './component/MyForm';
import UserList from './component/UserList';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={MyForm} />
        <Route path="/userlist" component={UserList} />
      </Switch>
    </Router>
  );
};

export default App;


// App.js
// import React from 'react';
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// // import UserList from './component/UserList';
// // import AddUserForm from './component/AddUserForm';
// import MyForm from './component/MyForm';

// function App() {
//   return (
//     <Router>
//       <Switch>
//         <MyForm/>
//       </Switch>
//     </Router>
//   );
// }

// export default App;
//         // <Route exact path="/add" component={AddUserForm} />
