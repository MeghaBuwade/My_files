import logo from './logo.svg';
//import './App.css';
import Card from './component/Card';

function App() {
  return (
    <div className='card_style'>
      <Card/>
      <Card/>
    </div>
  )
}

export default App;
