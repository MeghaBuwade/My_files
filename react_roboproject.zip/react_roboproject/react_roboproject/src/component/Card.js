import React from 'react';
import './App.css';
export default function Card(){
    return(
        <div>
            <img src="https://robohash.org/set_set4/" alt="card_robot"/>
            <div>
            <h2>Hello Megha</h2>
            <p>mdmegha1999@gmail.com</p>
            <h4>Age:23</h4>
        </div>
        </div>
        
        )
}