import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <button className="inc">-</button>
      <input type="number" name='count' />
      <button className="dic">+</button>

    </div>
  );
}

export default App;
