import logo from './logo.svg';
import './App.css';
import Part1 from './component/Part1';
import ProductList from './component/ProductList';
import Footer from './component/Footer';
function App() {
  const product =[
    {
      
    }
  ]
  return (
    <div className="App">
     <Part1/>
     <ProductList/>
     <Footer/>
    </div>
  );
}

export default App;

