import React,{useState,useEffect, useRef} from 'react'
import './index.css'
export default function Product(){
//title for note
  const[title, setTitle] = useState("");
  const [alltitle, setAllTitle] = useState([]);
//note
  const [note, setNote] = useState([]);
  const [allnote, setallNote] = useState([]);
  const [inputValue, setInputValue] = useState("");
//time runs
  // const [noteTime, setNoteTime]=useState(time);


const SaveNote =()=>{
  setallNote([...allnote, {
    id:note+allnote.length,
    title:title,
    note:note
  }])
  console.log(allnote) ;
  console.log(allnote.title);
}




//title
const titleChange = (event)=>{
  setTitle(event.target.value);
};

const deleteNote = (e, id) =>{
  e.preventDefault();
  setAllTitle(alltitle.filter((t) => t.id != id));
  setallNote(allnote.filter((t) => t.id != id));
};
const completeNote = (id) =>{
  let updatedNote = note.map((note)=>{
    if(note.id === id){
    note.completed = !note.completed
  }
  return note 
})
setNote(updatedNote)
}

// time
let time = new Date().toLocaleTimeString()
const [noteTime, setNoteTime]=useState(time);
const UpdateTime = () =>{
  time = new Date().toLocaleTimeString();
  setNoteTime(time);
}
setInterval(UpdateTime,1000);
let todayDate = new Date().toLocaleDateString()
//
// count-word 
  const count = useRef(0);

  useEffect(() => {
    count.current = count.current + 1;
  });


//

const noteChange = (event)=>{
  setNote(event.target.value);
};


   



return( 


  <div className='main-part'>
    <div className='main-content'>
      <button onClick={completeNote} className='save-btn'>Save</button>
      <div className='all-note-btn'>All Notes Delete👉<button className='allDelete' onClick={deleteNote}>❌</button></div>
      <div className='haid-part'>
        <input type="text" name="inputTitle" id="inpTitle"placeholder='Title....' onChange={titleChange}></input>
        <input type="text" name="inputNote" id="inpNote" placeholder='note....' onChange={noteChange} ></input>
        <button className='complet' onClick={SaveNote}>✔</button>
        <div className='timeDate'><p>{todayDate} , {time}  | </p>
            <h1>{count.current}</h1>
        </div> 
      
      </div>
      <div className='note-box'>
      
           {allnote.map((item)=>{
             <div key={item.title}>
            <h1>{item.title}</h1>
            <h3>{item.note}</h3>
             </div>
           }) 
}  
         </div>
      
         
      </div>
    
  </div>
)}







