import React from 'react'
import './index.css';
function ProductList() {
  return (
    <div className='main-comp'>
      <h1>Notes</h1>
      <div className='main'>
       <button className='edit'><h3>Edit</h3></button>
       <button className='sarch'>&#128269;</button>
       <button className='coustom'><h1>...</h1></button>
     </div>
    </div>
  )
}

export default ProductList;
