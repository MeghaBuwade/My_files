import React from 'react'
import './index.css';
 import Product from './Product.js'
export default function Footer() {

    return(
    <div>
        <Product/> 
        <div className='foot'>    
        <div><button className='note' >&#128221;<br/>New Note</button></div>
        </div>
    </div>
        )}