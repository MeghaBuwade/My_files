import React from 'react'
import Footer from './component/Footer'
import ProductList from './component/ProductList'
export default function App() {
  return (
    <div>
      <ProductList/>
      <Footer/>
    </div>
  )
}
