import logo from './logo.svg';
import './App.css';
import Pushpa from './components/Pushpa';
import Pro from './contex/Pro';


function App() {
  return (
    <div className="App">
      <Pushpa/>
    </div>
  );
}

export default App;
