const data = [
    {
        name: "test",
        year: 2020,
  Budget: 50,
  Rating:5,
         Cast: ['adf'],
  Reviews:['Good'],
  Language:'Hindi',

    }
]
export default data ;