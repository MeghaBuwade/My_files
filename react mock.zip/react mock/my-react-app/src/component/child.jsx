import React from 'react';
import mock from './mock';
export default function (child){
return(
    <div>
        <mock/>
    </div>
)
}
    

