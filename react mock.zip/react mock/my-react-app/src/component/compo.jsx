import React from 'react';

class compo extends React.Component {
// constructor(props) {
//     super(props);

//     this.state = {
//     };
// }

    render() {
        return <div>
            <h1>GO TO MY APP...... &#128073;</h1>
        </div>;
    }
}

//compo.propTypes = propTypes;
//compo.defaultProps = defaultProps;
// #endregion

export default compo;



