import React from "react";
import './App.css';
function Footer () {
   return(
       <div className="footer">
           <div>
               <p>They list everything that you have to do, with the most important tasks at the top of the list, and the least important tasks at the bottom.
                   By keeping such a list, you make sure that your tasks are written down all in one place so you don't forget anything important. </p>
           </div>
       </div>
   );
}
export default Footer;