import React,{useState} from 'react';
//import child from './src/component/child';
export default function (mock){

 const[num, setNum]=useState(1);




    return(
        <div>
            <div>
                <h1></h1>
            </div>
        </div>
    )
}
    

