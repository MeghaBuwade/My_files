
import './App.css';
import Header from './MyComponents/Header';
import {Todos}  from './MyComponents/Todos';
import {Footer} from './MyComponents/Footer';

function App() {
  const onDelet = ()=> {
   console.log("I am ondelete");
  }
  
  let todos = [
    {
      sno: 1,
      title:"",

    },
    {
      sno: 2,
      title:"",
    },
    {
      sno: 3,
      title:"",
    },
    {
      sno: 4,
      title:"",
    },
  ]
  return (
    <>
    <Header title="MyTodosList" searchBar={false}/>
    <Todos todos={todos} onDelet={onDelet}/>
    <Footer/>
    </>
     
    
    //div to div == jsx not html (html aj js se mil k)
  );
}

export default App;
