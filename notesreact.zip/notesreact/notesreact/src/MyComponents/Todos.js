import React from 'react';
import {Todo} from '../MyComponent/Todo';

export const Todos = (props) => {
  return ( 
  <div className='container'>
    <h2 className='text-center'>ToDoS LiSt</h2>
 {props.todos.map((todo)=>{
     return <Todo Todo={todo} onDelete={props.onDelete}/>
 })}
 
  </div>
  )
};
