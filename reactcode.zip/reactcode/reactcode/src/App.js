import logo from './logo.svg';
import UseRreducer from './Hooks/UseRreducer';
import  UseCcallback from './Hooks/UseCcallback';
import './App.css';

function App() {
  return (
    <div className="App">
     <UseRreducer/>
      <UseCcallback/> 
    </div>
  );
}

export default App;
