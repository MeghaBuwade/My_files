import React, {useCallback, useState} from 'react';
import Child from './Child';
// use callback memoized k liye use kiya jata h
// 
export default function UseCcallback() {
    const [countone,setCountone] = useState (0)
    const [counttwo,setCounttwo] = useState (0)
    //use callback ka use use memoraizetion k liye krege
    const getItems = useCallback(()=>{
     
        console.log(counttwo+1,counttwo-1);
        for(let i=0;i<1000000000; i++){}
        console.log('getItems')
          return [counttwo+1,counttwo-1]
      
     },[counttwo])
    
  return (
    <div>
      <button onClick={()=> setCountone(countone+1)}>Count One: {countone}</button>
      <button onClick={()=> setCounttwo(countone+1)}>Count Two: {counttwo}</button>
      <Child getItems={getItems}/>
    </div>
  )
}













