// the useReducer Hook is similaar to the useState Hook.
// it allows for custom state logic.
// if you find yourself keeping track of multiple pieces of state that rely on complex logic, useReducer may be useful.
// the useReducer hook accepts two arguments.
// the reducer function contains your custom state logic and the initialState can be a simple value but generally will 
    // contain an object.
// the useReducer Hook returns the current stte and a dispatch method.



// A functionis considered pure, if adheres to the following rules:
   // 1. The function always returns the same output if the same arguments are passed in.
   // 2. The function does not produce any side-effects.



import React, {useReducer} from 'react'

const initialState = 0;
const reducer = (state, action)=>{
    console.log(state, action);
    if (action.type === 'Incriment'){
        return state + 1;
    }
    if (action.type === 'Dicriment'){
        return state - 1;
    }
return state;
}
const UseRreducer = ()=>{
const [state, dispatch] = useReducer(reducer, initialState);
 return (
    <div>
        <p>{state}</p>
        <div>
            <button onClick={()=> dispatch({type: "Incriment"})}>+</button>
            <button onClick={()=> dispatch({type: "Dicriment"})}>-</button>
        </div>
      
    </div>
  )
}
export default UseRreducer;







React?
Why facebook chose react? NA (Not answered)
Advantage of react?
Is library or framework? NA
library vs framework? NA
Class vs functional component ? Which is faster? NA
react life cycle? - Incorrect
Describe each of phases? - Incorrect
Virtual DOM? -Incomplete
How many VDOM is there? NA
Reconciliation?  NA
How react works? NA
props?
state vs props?
prop drilling? NA
how to deal with prop drilling? NA
UseContext ? NA
Implement useContext? NA
react Hooks? NA
React pass data One way?  NA
pass data from child to parent?
Pass data between 2 child components? how?
Controlled vs uncontrolled components? NA
Map vs reduce vs filter? NA
UseState? NA
Higher-Order components? NA
useRef? NA

NA -->
Why we use Super in constructor with props? NA
-constructor(props) {
        super(props);
                  VS
constructor(props) {
        super();
React component extends which class? NA
StrictMode?
Bundling?
JSX?
React.CreateElement? NA
Limitations? 
Angular vs React?
component-based architecture of React? NA
Redux? NA
Synthetic events? NA
Advantage of hooks? NA
Keys in React?
Why we use second argument that is passed to UseEffect? Is it optional?
UseEffect?
async?
Single threaded or multi?
promise vs async await?
try catch?
Unit testing?
Coding to call open api and render?








void deleteNode(int key)
    {
        
        Node tmp = head, prev = null;
 
        
        if (tmp != null && tmp.data == key) {
            head = tmp.next; 
            return;
        }
 
        
        while (tmp != null && tmp.data != key) {
            prev = tmp;
            tmp = tmp.next;
        }
 
        
        if (tmp == null)
            return;
 
        
        prev.next = tmp.next;
    }
 
    
    public void push(int new_data)
    {
        Node new_node = new Node(new_data);
        new_node.next = head;
        head = new_node;
    }






