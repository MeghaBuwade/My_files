// import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import Home from './Pages/Home'; // Adjust the path if necessary
// import DontMiss from './Pages/DontMiss';
// import ProductList from './Pages/ProductList';
// import ManuData from './Pages/ManuData'; // Adjust the path if necessary

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/dont-miss" element={<DontMiss />} />
//         <Route path="/products" element={<ProductList />} />
//         <Route path="/manu-data" element={<ManuData />} />
//       </Routes>
//     </Router>
//   );
// }

// export default App;





// import "./styles.css";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";


export default function App({assignEmployee,setAssignEmployee, assetCategory,setAssetCategory}) {
  

  const handleChange = (event) => {
    setAssignEmployee(event.target.value);
  };
   const handleChangeAsset = (event) => {
    setAssetCategory(event.target.value);
  };


  return (
    <div> <FormControl sx={{ m: 1, minWidth: 140 }} size="small">
        {/* <InputLabel sx={{ marginTop:"0px" ,fontSize:"15px" }} id="demo-select-small-label">
      ---select---
      </InputLabel> */}
        <Select
          labelId="demo-select-small-label"
          id="demo-select-small"
          value={assignEmployee}
          // label="Age"
          onChange={handleChange}
        >
          <MenuItem value="Unassigned">--UNASSIGNED--</MenuItem>
          <MenuItem value={"Empl"}>Employee1</MenuItem>
          <MenuItem value={"Emp2"}>Employee2</MenuItem>
          <MenuItem value={"Emp3"}>Employee3</MenuItem>
        </Select>
      </FormControl>
      <FormControl sx={{ m: 1, minWidth: 140 }} size="small">
      <InputLabel sx={{ marginTop:"0px" ,fontSize:"15px" }} id="demo-select-small-label">
       ---select---
      </InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={assetCategory}
        // label="Age"
        onChange={handleChange}
      >
        {/* <MenuItem value="">
          <em>None</em>
        </MenuItem> */}
        <MenuItem value={10}>Category1</MenuItem>
        <MenuItem value={20}>Category2</MenuItem>
        <MenuItem value={30}>Category3</MenuItem>
      </Select>
    </FormControl></div>
     
    
      
  );
}

// export default App;


//   const [ag, setAge] = React.useState("");

  
