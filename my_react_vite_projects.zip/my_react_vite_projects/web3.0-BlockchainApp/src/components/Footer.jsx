const Footer = () => {
    return (
        <footer className="w-full flex md:justify-center bg-black color-pink">
        <div>
        higkhn
        </div>
        
        
        </footer>
    );
}
export default Footer;