import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import Deshboard from './components/Deshboard';

function App() {
  return (
    <div className="App">
      <Header />
      <Home />
      <Deshboard />
    </div>
  );
}

export default App;
