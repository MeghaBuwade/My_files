import React from "react";
import hamburger from "./svg_file/hamburger.svg";
import Ellipse from "./svg_file/Ellipse 16.svg";
import Group from "./svg_file/Group 29.svg";
import upcoming from "./svg_file/upcoming events-icon.svg";
import Vector from "./svg_file/Vector.svg";
import VectorA from "./svg_file/VectorA.svg";
import messages from "./svg_file/messages-icon.svg";

import logout from "./svg_file/logout-icon.svg";
import dashboard from "./svg_file/dashboard.svg";
import "./Style.css";
export default function Home() {
  return (
    <div className="home-contener">
      <div className="rectangle-home">
      <div className="home-icons">  
            <img src={hamburger} />
      </div>
        <div className="home-icons">
          <img src={dashboard} />
          Doshboard
        </div>
        <div className="home-icons">
          <img src={VectorA} />
          <img src={Vector} />
          My Jobs
        </div>
        <div className="home-icons">
          <img src={messages} />
          Messages
        </div>
        <div className="home-icons">
          <img src={upcoming} />
          Upcoming Events
        </div>
        <img src={Group} />

        <img src={Ellipse} />
      </div>
      <div>
        <button>HELP</button>
        <div>
          <img src={logout} />
          Log Out
        </div>
      </div>
    </div>
  );
}
