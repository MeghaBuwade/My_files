import React from "react";
import "./Deshboard.css";

export default function Deshboard() {
  return (
    <div className="deshboard">
      <div>
        <h1 className="title">Dashboard</h1>
        <h5 className="jon-search">Job search status</h5>
        <button>Actively Interviewing</button>
      </div>
      <div className="applications">
        <div className="application_title">Applications</div>
        <div className="box-1">
          <img src="../../public/Rectangle 293.jpg" />
          <img src="./Rectangle 293.jpg" />
          <div>
            <h4>Senior Product Designer</h4>
            <span className="name-work">Techmint , On-site</span>
            <span className="loction">Bengaluru, India</span>
          </div>
          <div>
            <span className="rs">₹ 50K - ₹ 70K</span>
            <span className="time-p">Per Month</span>
          </div>

          <button className="applications_rejected_btn">Rejected</button>
        </div>
        <div className="box-2">
        <img src="../../public/Rectangle 293.jpg" />
        <img src="./Rectangle 293.jpg" />
        <div>
          <h4>Senior Product Designer</h4>
          <span className="name-work">Techmint , On-site</span>
          <span className="loction">Bengaluru, India</span>
        </div>
        <div>
          <span className="rs">₹ 50K - ₹ 70K</span>
          <span className="time-p">Per Month</span>
        </div>

        <button className="applications_rejected_btn">Rejected</button></div>
        <div className="box-3">
        <img src="../../public/Rectangle 293.jpg" />
        <img src="./Rectangle 293.jpg" />
        <div>
          <h4>Senior Product Designer</h4>
          <span className="name-work">Techmint , On-site</span>
          <span className="loction">Bengaluru, India</span>
        </div>
        <div>
          <span className="rs">₹ 50K - ₹ 70K</span>
          <span className="time-p">Per Month</span>
        </div>

        <button className="applications_rejected_btn">Rejected</button></div>
      </div>
      <div className="job-recomm-1">
      </div>
      <div className="event-reminder-rect"></div>
      <div></div>
    </div>
  );
}
