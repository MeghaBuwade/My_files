import React from "react";
import "./Style.css";
import award from './svg_file/award.svg'
import Group from "./svg_file/GroupA.svg"
import messages from "./svg_file/messages-icon.svg";

export default function Header() {
  return (
    <div className="header_contener">
      <div className="logo_content"></div>
      <div className="input-search">
        <svg
          className="input_svg"
          xmlns="http://www.w3.org/2000/svg"
          width="27"
          height="29"
          viewBox="0 0 27 29"
          fill="none"
        >
          <path
            d="M22.5279 14.1555C21.5445 19.7326 16.3258 23.4741 10.8717 22.5124C5.41754 21.5507 1.79328 16.2499 2.77666 10.6729C3.76005 5.09577 8.97871 1.35427 14.4329 2.31599C19.887 3.27769 23.5113 8.57845 22.5279 14.1555Z"
            stroke="black"
            stroke-width="2.7344"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M22.9061 27.4112L18.3765 20.7863"
            stroke="black"
            stroke-width="2.7344"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
        <input className="inp" type="text" placeholder="Type for Search" />
      </div>
      <div className="icons">
       
        <img className="msg" src={messages}/>
        <img className="notification" src={Group}/>
        <img className="award" src={award}/>
          
      </div>
      <div className="profile">
        <img className="profile_img"></img>
      <div className="profile_name">
          Akash Mishra
        <button>EDIT MY PROFILE</button>
      </div>
      </div>
        
    </div>
  );
}
// <input placeholder='Type for Search'/>
