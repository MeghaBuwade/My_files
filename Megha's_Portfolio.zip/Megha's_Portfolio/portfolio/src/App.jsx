// import React from "react";
import Header from "./components/Header";
// import Home from "./components/Home";
import About from "./components/About";
import Skills from "./components/Skills";
import Education from "./components/Education";
// import Projects from "./components/Projects";
// import Contact from "./components/Contact";
// import LeetcodeCont from "./components/LeetcodeCont";
import "./App.css";

function App() {
  return (
    <>
      <Header/>
      <div className="portfolio">
      <About/>
      <Skills/>
      <Education/>
      
      
      </div>
    </>
  );
}

export default App;
