import React from "react";

const Projects = () => {
  return (
    <section className="work" id="work">
      <div className="title">
        <h2 className="section-title">My Projects</h2>
      </div>

      <div className="content">
        <div className="project-card">
          <h3>Dog Gallery</h3>
          <p>React + Fetch API based dog search platform.</p>
        </div>

        <div className="project-card">
          <h3>Tic Tac Toe</h3>
          <p>HTML, CSS, JS Game with animations.</p>
        </div>
      </div>
    </section>
  );
};

export default Projects;