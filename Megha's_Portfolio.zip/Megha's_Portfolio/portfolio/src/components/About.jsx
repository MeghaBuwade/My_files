import React from "react";
import "./About.css";
// import profileImg from "../images/Screenshot 2023-08-03 155144.jpg";

const About = () => {
  return (
    <section className="about" id="about">
      <div className="title">
        <h2 className="section-title">About Me</h2>
      </div>

      <div className="content">
        <div className="column col-left">
          <div className="img-card"></div>
        </div>

        <div className="column col-right">
          <h2>Hey There!</h2>
          <p>
            I am a developer focused on creating modern web applications with
            clean design and efficient functionality. My work involves building
            responsive interfaces, integrating APIs, and developing scalable
            solutions using React.js, JavaScript, Python, Flask, and automation
            tools. I enjoy turning ideas into practical digital products and
            continuously exploring new technologies to improve development
            quality.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
// <img src={profileImg} alt="Megha" />
