import React, { useState } from "react";
import "./Header.css";

const Header = () => {
  const [darkMode, setDarkMode] = useState(true);

  const toggleTheme = () => {
    document.body.classList.toggle("light-theme");
    setDarkMode(!darkMode);
  };

  return (
    <header className="header">
      <a href="#main" className="logo">
        Logo
      </a>

      <nav className="nav">
        <a href="#main">Home</a>
        <a href="#about">About</a>
        <a href="#skills">Skills</a>
        <a href="#services">Education</a>
        <a href="#work">Projects</a>
        <a href="#contact">Contact</a>

        <a href="/Megha_Digarse_Resume.pdf" download className="resume-btn">
          Resume
        </a>

        <button onClick={toggleTheme} className="theme-btn">
          {darkMode ? "☀️" : "🌙"}
        </button>
      </nav>
    </header>
  );
};

export default Header;