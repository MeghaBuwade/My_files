import React from "react";

const Education = () => {
  return (
    <section className="services" id="services">
      <div className="title">
        <h2 className="section-title">My Education</h2>
      </div>

      <div className="content">
        <div className="card">
          <h3>B.Tech in Electrical Engineering</h3>
          <p>Millennium Institute of Technology & Science</p>
        </div>

        <div className="card">
          <h3>Diploma in Electrical Engineering</h3>
          <p>Government Polytechnic College</p>
        </div>
      </div>
    </section>
  );
};

export default Education;