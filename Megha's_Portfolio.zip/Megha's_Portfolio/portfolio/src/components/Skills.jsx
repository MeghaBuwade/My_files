import React from "react";
import "./Skills.css";  

const Skills = () => {
  const skills = [
    "JavaScript",
    "React.js",
    "Python",
    "Flask",
    "Selenium",
    "Node.js",
    "Express.js",
    "MongoDB",
    "SQL",
    "Git",
    "REST API",
    "CSS",
  ];

  return (
    <section className="skills" id="skills">
      <div className="title">
        <h2 className="section-title">My Skills</h2>
      </div>

      <div className="content">
        <div className="column col-left">
          <h2>Technologies I Work With</h2>
          <p>
            I work with modern web technologies to build responsive,
            scalable, and efficient applications across frontend,
            backend, and automation development.
          </p>
        </div>

       <div className="skills-list">
  <div className="skill-item">JavaScript</div>
  <div className="skill-item">React.js</div>
  <div className="skill-item">Python</div>
  <div className="skill-item">Flask</div>
  <div className="skill-item">Selenium</div>
</div>
      </div>
    </section>
  );
};

export default Skills;