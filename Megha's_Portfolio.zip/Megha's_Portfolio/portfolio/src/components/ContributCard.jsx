import React from "react";

function ContributionGrid() {
  return (
    <div className="grid grid-cols-53 gap-1 overflow-x-auto">
      {Array.from({ length: 365 }).map((_, i) => (
        <div
          key={i}
          className="w-3 h-3 rounded-sm bg-gray-300 hover:scale-110 transition"
        ></div>
      ))}
    </div>
  );
}
export default function ContributionCard() {
  return (
    <div>
    <div className="p-6 max-w-4xl mx-auto mt-10 grid gap-6">
      <h1 className="text-2xl font-bold text-center mb-6">
        Developer Contributions
      </h1>
      
      <div className="bg-white shadow-xl rounded-2xl p-6">
        <h2 className="text-xl font-semibold mb-4">
          GitHub Style Contribution Grid
        </h2>
        <ContributionGrid />
      </div>

      <div className="bg-white shadow-xl rounded-2xl p-6">
        <h2 className="text-xl font-semibold mb-4">GitHub Contributions</h2>
      
    <img
      src={`https://ghchart.rshah.org/00b300/mdmegha1999?${Date.now()}`}
      alt="GitHub Contribution Graph"
      className="w-full rounded-xl"
    />

        <p className="text-sm mt-2 text-gray-500 text-center">
          Showing contributions for <b>mdmegha1999</b>.
        </p>
      </div>

    </div> 
    </div>
  );
}
