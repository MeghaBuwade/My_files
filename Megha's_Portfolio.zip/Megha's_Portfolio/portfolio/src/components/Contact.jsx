import React from "react";
import { FaLinkedin, FaGithub, FaEnvelope, FaPhone } from "react-icons/fa";

const Contact = () => {
  return (
    <section className="contact" id="contact">
      <div className="title">
        <h2 className="section-title">Contact Me</h2>
      </div>

      <div className="contact-icons">
        <a href="https://www.linkedin.com/in/megha-digarse-6888981a6/">
          <FaLinkedin />
        </a>

        <a href="mailto:mdmegha1999@gmail.com">
          <FaEnvelope />
        </a>

        <a href="tel:+916261392766">
          <FaPhone />
        </a>

        <a href="https://github.com/mdmegha1999">
          <FaGithub />
        </a>
      </div>
    </section>
  );
};

export default Contact;