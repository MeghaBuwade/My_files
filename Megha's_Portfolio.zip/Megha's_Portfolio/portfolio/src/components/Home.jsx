// import React from "react";
import './Home.css'
// import { FaInstagram, FaLinkedin, FaGithub, FaFilePdf } from "react-icons/fa";

// const Home = () => {
//   return (
//     <section className="main" id="main">
//       <div className="content">
//         <h2>Hello, I'm <br /><span>Megha Digarse</span></h2>

//         <div className="animated-text">
//           <h3>Full Stack Web Developer</h3>
//           <h3>Python Developer</h3>
//         </div>

//         <a href="#work" className="btn">See My Work</a>

//         <div className="media-icons">
//           <a href="#"><FaInstagram /></a>
//           <a href="https://www.linkedin.com/in/megha-digarse-6888981a6/" target="_blank" rel="noreferrer">
//             <FaLinkedin />
//           </a>
//           <a href="https://github.com/mdmegha1999" target="_blank" rel="noreferrer">
//             <FaGithub />
//           </a>
//           <a href="/Megha_FullStack_Web_Development.pdf">
//             <FaFilePdf />
//           </a>
//         </div>
//       </div>
//     </section>
//   );
// };

// export default Home;
// import React from "react";
// import { motion } from "framer-motion";

// export default function MeghaPortfolio() {
//   const projects = [
//     "CRM System",
//     "Food Delivery App",
//     "KYC Microservice",
//     "PDF Compression API",
//     "Selenium Automation"
//   ];

//   return (
//     <div className="min-h-screen bg-black text-white overflow-hidden relative">
//       <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,255,255,0.15),transparent_40%)]"></div>

//       <section className="relative z-10 flex flex-col items-center justify-center text-center py-24 px-6">
//         <motion.h1
//           initial={{ opacity: 0, y: -20 }}
//           animate={{ opacity: 1, y: 0 }}
//           className="text-5xl font-bold mb-4"
//         >
//           Megha Digarse
//         </motion.h1>

//         <p className="text-lg text-cyan-300 mb-6">
//           Full Stack Developer | Python | React | Flask
//         </p>

//         <p className="max-w-2xl text-gray-400 mb-8">
//           Building scalable web applications, APIs and automation solutions.
//         </p>

//         <div className="flex gap-4 flex-wrap justify-center">
//           <button className="rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-black px-6 py-3">
//             View Projects
//           </button>

//           <button className="rounded-2xl border border-cyan-500 text-cyan-300 px-6 py-3">
//             Download Resume
//           </button>
//         </div>
//       </section>

//       <section className="relative z-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6 px-8 py-16">
//         {projects.map((project, index) => (
//           <motion.div
//             key={index}
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ delay: index * 0.2 }}
//             className="bg-white/5 border border-cyan-500/20 rounded-2xl shadow-[0_0_30px_rgba(0,255,255,0.15)] backdrop-blur-xl p-6"
//           >
//             <div className="h-40 rounded-xl bg-gradient-to-br from-cyan-500/20 to-transparent mb-4"></div>
//             <h3 className="text-xl font-semibold text-white mb-2">{project}</h3>
//             <p className="text-gray-400 text-sm">
//               Modern scalable solution with production-ready architecture.
//             </p>
//           </motion.div>
//         ))}
//       </section>

//       <section className="relative z-10 py-20 px-8 text-center">
//         <h2 className="text-3xl font-bold mb-8">Skills</h2>

//         <div className="grid md:grid-cols-4 gap-4 max-w-5xl mx-auto">
//           {[
//             "React",
//             "Python",
//             "Flask",
//             "MongoDB",
//             "MySQL",
//             "Docker",
//             "Selenium",
//             "Node.js"
//           ].map((skill, index) => (
//             <div
//               key={index}
//               className="bg-white/5 rounded-2xl py-4 border border-cyan-500/20 shadow-[0_0_20px_rgba(0,255,255,0.1)]"
//             >
//               {skill}
//             </div>
//           ))}
//         </div>
//       </section>
//     </div>
//   );
// }
import React from "react";
// import "./AnimatedCenter.css";

// import React from "react";
// import "./GlowLine.css";

export default function GlowLine() {
  return (
    <div className="hero-section">
      <div className="glow-line"></div>
    </div>
  );
}