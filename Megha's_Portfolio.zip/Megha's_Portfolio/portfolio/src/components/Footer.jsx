import React from "react";
import { FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa";

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <div style={styles.container}>
        
        {/* Left Section */}
        <div style={styles.section}>
          <h2 style={styles.logo}>Megha Digarse</h2>
          <p style={styles.text}>
            Full Stack Developer | React & Python Developer
          </p>
        </div>

        {/* Middle Section */}
        <div style={styles.section}>
          <h3>Quick Links</h3>
          <ul style={styles.list}>
            <li><a href="#home" style={styles.link}>Home</a></li>
            <li><a href="#about" style={styles.link}>About</a></li>
            <li><a href="#projects" style={styles.link}>Projects</a></li>
            <li><a href="#contact" style={styles.link}>Contact</a></li>
          </ul>
        </div>

        {/* Right Section */}
        <div style={styles.section}>
          <h3>Follow Me</h3>
          <div style={styles.socialIcons}>
            <a href="#" style={styles.icon}><FaLinkedin /></a>
            <a href="#" style={styles.icon}><FaGithub /></a>
            <a href="#" style={styles.icon}><FaInstagram /></a>
          </div>
        </div>

      </div>

      <div style={styles.bottom}>
        © {new Date().getFullYear()} Megha Digarse | All Rights Reserved
      </div>
    </footer>
  );
};

const styles = {
  footer: {
    backgroundColor: "#111",
    color: "#fff",
    padding: "40px 0 0 0",
  },
  container: {
    display: "flex",
    justifyContent: "space-around",
    flexWrap: "wrap",
    padding: "0 20px",
  },
  section: {
    margin: "20px",
    minWidth: "250px",
  },
  logo: {
    fontSize: "22px",
    marginBottom: "10px",
  },
  text: {
    color: "#aaa",
  },
  list: {
    listStyle: "none",
    padding: 0,
  },
  link: {
    color: "#aaa",
    textDecoration: "none",
    display: "block",
    margin: "8px 0",
  },
  socialIcons: {
    display: "flex",
    gap: "15px",
    fontSize: "20px",
  },
  icon: {
    color: "#fff",
  },
  bottom: {
    textAlign: "center",
    padding: "15px",
    marginTop: "20px",
    borderTop: "1px solid #333",
    fontSize: "14px",
    color: "#aaa",
  },
};

export default Footer;