// What is javascript ?
// why study javascript ?
// JavaScript where to ?
// What are Variables ?
// Difference between var,let and const keywords in JavaScript ?
// What is javascript Data Types ?
// what is Block Scope ?
            //Block Level Scope: This scope restricts the variable that is
            // declared inside a specific block, from access by the outside
            // of the block. The let & const keyword facilitates the variables
            // to be block scoped.
// When to use JavaScript const?
// what is javascript operators ?
// let x = 5 + 5;
// let y = "5" + 5;
// let z = "Hello" + 5;
// var x = 3>2>1;
// == vs ===
// != vs !==


// what is arrays 
             // 
// what is js objects ?

// object Properties ?
// object Methods ?
// what is function ?
// what is local variables ?
// what is this ?
// What is Hoisting in js and exampal ?
// what is closure in js ?
// what is callback in js ?
//

/*
1. Create a static page containing 3 parts - header in top, main section & 
footer in bottom. Header will contain 3 links for home, About us, Blog. In main section,
create a registration form having 5 fields (first name, last name, address,
city, Pincode and a submit button. Footer will have 3 links Careers, blog, Team. Also 
apply validations in form using Javascript.

2. Place form in center of screen

Design a layout
Closure in javascript
What is IIFE
What is callback
write a promise
What is hoisting 


What are tags and attributes in HTML? 
 How to create a hyperlink in HTML? 
 What is semantic HTML?  
give a name of block level and inline? 
 what is datalist tag? 
What do you understand by pseudo-elements? 
What is the difference between a class and an ID?
Define z-index.? 
How can you use CSS to control image repetition? 
What are the different types of Selectors in CSS?
explain position property in css? 
absolute in CSS? 
Is javascript a statically typed or a dynamically typed language? --answered 
datatype in js? -- answered 
Explain Implicit Type Coercion in javascript.? -not answered output:console.log(3>2>1)? --not answered 
II)console.log(3+"3"); 
III)console.log(3-"3"); 
 what is arrow function? 
what is closure? 
What is scope in javascript? 
difference between var,let,const? 
 create increment decrement counter? 
 create login form move to center and aplly null varefication
centre a div inside another div? 

What is difference between HTML/HTML5?

What is DOCTYPE tag?

Explain the usage of charset in meta tag?

Explain the difference between id and name attribute usage in HTML?

Design a form in HTML asking Email ID and Password where both are mandatory to fill.

What is difference between div & span tag?

Which is having higher precedence inline CSS or external CSS?

What is difference between pseudo class and pseudo element?

What is difference between :after & ::after

1. What all new features got introduces in html 5?

2. What is web worker?

3. What all different storages we have in browser? ( local storage, session storage and cookie) 

4. What is script async and script defer?

5.What is html canvas?

6. Different between svg and canvas?

7. What is box model in css?  

8.  What is flex in css? 

9. Create a circle and place a text in the centre of the circle?  

10. What is the basic difference between let and var? 

11. What is hoisting in JS?

12. What is closure in JS?

13. What is callback in JS?

14. What is promises in JS?
15. What is async await? 

16. You have to create a counter which will trigger on the submit button. Once you click on the button it will increment. 
 1) What is CSS and how does it work with HTML?
 2) What is the Box model in CSS? 
 3) What's the difference between a relative, fixed, absolute and statically positioned element?
 4) What are void elements in HTML?
 5) Is some compiler required to run html? 
 6) Difference between block and inline elements 
 7) Difference between div tag and span tag. 
 8) What are the New tags in Media Elements in HTML5? 
 9) What is asynchronous & synchronous in JS? Any examples ? 
 10) What is a promise and how it works? 
 11) Explain event delegation 
 12) Explain pass by value and pass by reference. 
 13) Create a static page for conference event.
   Divide your page into 3 parts - header in top, main section & footer in bottom.
   Mention different links for speaker, venue & schedule in header section.
   In main section, create a registration form for users for attending an event. 
   Then last add footer section. Using HTML/HTML5 & CSS complete this static page,
   showcasing your knowledge in depth. 
 14) Follow-up questions on above
 1. What all new features got introduces in html 5?
 2. What is web worker?
 3. What all different storages we have in browser?  ( local storage, session storage and cookie) 
 4. What is script async and script defer? 
 5.What is html canvas? 
 6. Different between svg and canvas? 
 7. What is box model in css?
 8. What is flex in css? 
 9. Create a circle and place a text in the centre of the circle?
 10. What is the basic difference between let and var?
 11. What is hoisting in JS? 
 12. What is closure in JS?
 13. What is callback in JS? 
 14. What is promises in JS?
 15. What is async await? 
 16. You have to create a counter which will trigger on the submit button. Once you click on the button it will increment. 
 Design a layout Closure in javascript What is IIFE What is callback write a promise What is hoisting Event loop
 1. Create a payment app the fields are - name of the account holder- account no- confirm account no - available balance - amount to be debited- ifsc code - payment channel - mobile no - calculate the current balance after withdrawal and show the result 1. all the fields are required. 2. account no and confirm account no should be same 3.mobile no should be of 10 digits 4. check if the available balance is greater than the amount to be withdrawn

 */
/*

 1. Do you know about inline and block elements.
2. Create a div and span tag with a red background? What you will observe when you open it in browser w.r.t span and div tag.
3. What are arrow functions.
                // Arrow function is one of the features introduced
                 in the ES6 version of JavaScript. It allows you to 
                 create functions in a cleaner way compared to regular functions
4. What is var, let, and const.
5. What do you mean by block scoped. The output of -: 
(i){
    let a=5
}
console.log(a)
(ii) {
    var a=5
}
console.log(a)
(iii) function myFunc(){
    var a =5
    return 2
}
myFunc()
console.log(a)
6. What is hoisting?
7. Output of - :
(i)console.log(myFunc)
var myFunc = function(){
    return 5
}
(ii) console.log(myFunc())
var myFunc = function(){
    return 5
}
(iii) console.log(myFunc)
function myFunc(){
    return 5
}
8. Asked to open the project. Then told her to change the promise code to async and await.
9. Given one sample API link which has mock data in it and told her to print all the names that API is returning.
10. Do you know about map and filter.
11. Create a box and center align it horizontally as well as vertically using flex.
*/