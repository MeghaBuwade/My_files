//!  Sorting Algorithm
/* 
A sorting Algorithm is used to rearrange a give array or list
elements according to a comparison operator on the elements.
The comparison operator is used to decide the new order of 
elements in the respective data structure.
*/