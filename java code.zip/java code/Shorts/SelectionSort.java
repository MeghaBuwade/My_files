// one swap par one iteration 
 /*
     7 4 9 1 3 2
smallest element swap
     1 4 9 7 3 2
     1 2 9 7 3 4
     1 2 3 7 9 4
     1 2 3 4 9 7
     1 2 3 4 7 9

 */

 // time complexity = O(n^2)

import java.util.*;
class SelectionSort{
    public static void printArray(int arr[]){
        for(int i=0; i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }

          //*smallest to highest number ya element

    // public static void main(String args[]){
    //     int arr[] = {7, 4, 9, 1, 3, 2};
    //     for(int i=0; i<arr.length-1; i++){
    //         int smallest =i;
    //         for(int j=i+1; j<arr.length; j++){
    //             if(arr[j]<arr[smallest]){
    //                 smallest=j;
    //             }
    //         }
    //         int temp = arr[smallest];
    //         arr[smallest]=arr[i];
    //         arr[i]=temp;
    //   }


         //*smallest to highest number ya element

        public static void main(String [] args){
           int arr[] = {7, 4, 9, 1, 3, 2, 0};

          for(int i=0; i<arr.length; i++){
          int highest =i;
          for(int j=i+1; j<arr.length; j++){
            if (arr[j]>arr[highest]){
                highest=j;
            }
          }
          int temp = arr[highest];
           arr[highest]=arr[i];
           arr[i]=temp;
        }

    printArray(arr);
        

       }
}