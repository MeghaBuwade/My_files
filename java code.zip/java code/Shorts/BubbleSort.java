/** 
     7  9  6  3  2  1

  1.=> comparison 7  and  9 
      9 comparison all element    7 6 3 2 1 9
  2. => comparison 7 and  6  
      7 comparison all element    6 3 2 1 7 9
  3.=> comparison 6 and 3         3 2 1 6 7 9
    6 comparison all element      2 1 3 6 7 9
                                  1 2 3 6 7 9
 */


// idea : if arr[i]>arr[i+1] swap them.
// To place the element in their respective position ,
// we have to do the following operation N-1 times.

// Time Comolexity : O(N^2)

import java.util.*;
class BubbleSort{
    public static void printArray(int arr[]){
        for(int i=0; i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
    //time complrxity = 0(n^2) [big O of N sqear]
    public static void main(String args[]){
      int arr[] = {7, 9, 6, 3, 2, 1};
      for(int i=0; i<arr.length-1; i++){ // run = n-1 time
        for(int j=0;j<arr.length-i-1;j++){ // run = 
            if(arr[j]>arr[j+1]){
                //swap
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
      }
      printArray(arr);
    }
    
}