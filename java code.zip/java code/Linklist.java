class Linklist{
    public static void main(Int[] nums){
       int arr[]= {1, 2, 3, 4, 5, 6};
       int key = 4;
       int result = Arrays.binarySearch(arr,key);
       if(result < 0)
  
    }
}
