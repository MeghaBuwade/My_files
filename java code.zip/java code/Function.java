//function - block of code
// return type - all type of datatype
// pubilc and static - keyword
// functionName - ---
//argument type- tyoe arg...
// returnType functionName(type arg1, type arg2..){

// }

 import java.util.*;
// public class Function{
//     public static void printMyName(String name){
//         System.out.println(name);
//         return ;
//     }
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         String name = sc.next();
//         printMyName(name);
//     }
    
// }


// * Make a function to add 2 numbers and return the sum

// public class Function{
//     public static int calculateSum(int a, int b){
//         int sum = a + b;
//         return sum;
//     }
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int a = sc.nextInt();
//         int b = sc.nextInt();
//         int sum = calculateSum(a, b);
//         System.out.println(sum);
//     }
// }

// Make a function to multiply 2 numbers and return the product.
// public class Function{
//     public static int calculateMul(int a, int b){
    
//         int multiply = a * b;
//         return multiply;
//     }
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int a = sc.nextInt();
//          int b = sc.nextInt();
//         int multiply = calculateSum(a, b);
//         System.out.println(multiply);
//     }
// }

// * Find the factorial of a number.
// n! = n*(n-1)*(n-2)*(n-3).....*1
// 0! = 1

public class Function{
//  public static void printFactorial(int n){
//     if(n<0){
//         System.out.println("Invalid Number");
//         return;
//     }
//     int factorial = 1;
//     for(int i=n; i>=1;i--){
//         factorial = factorial * i;
//     }
//     System.out.println(factorial);
//     return;
// }
// public static void main(String args[]){
//     Scanner sc = new Scanner(System.in);
//     int n = sc.nextInt();
//     printFactorial(n);
// }



 }