//Searching in DSA Java...
    /*Searching is an operation or a technique
     that helps finds the place of a given element or value in the list.
     Any search is said to be successful or unsuccessful depending upon 
     whether the element that is being searched is found or not.
     Some of the standard searching technique that is being followed 
     in the data structure is listed below:

     1. Linear Search or Sequential Search
     2. Binary Search
     */
import java.util.Scanner;
import  java.util.*;
class First{
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i = 0; i < n; i++){
            arr[i] = sc.nextInt();
        }
        int x = sc.nextInt(); //file kaha pe save hai wait run karao
        //pata nhi
      

                  //find an element x in array. run krao f9 se hai key run kya
         //1. linear Search done na ..? haa thank are koi nhi 
        
        for(int i = 0; i < n; i++){
            if (arr[i] == x){
                System.out.println("hello" + arr[i]);
                break;
            }
        }
  // closed();
    }
}
    

       
//        class text{  
//     public static void main(String args[]){  
        
//      System.out.println("Hello Java");  
//     }  
// }  
