// class String{
//     public static void main(String[] args){
//         int arr[] = {0,-1,-2,-3,1};
//         int n = arr.length;
//          int x = -2;
//         for(int i=0; i<n-1; i++){
//             for(int j=(i+1); j<n; j++){
//                 if(arr[i]+arr[j]== x){
//                     System.out.print("pair sum" + arr[i] + " " + arr[j]);
//                 }
//             }
            
//         }
        
//     }
// }



// class HelloWorld {
//     public static void search (int arr[], int x){
//         //int arr[] = {30, 58, 83, 85, 63, 74};
//         int n = arr.length;
//         // int x = 58;
//         for(int i =0;i<n; i++){
//             if(arr[i] == x){
//             System.out.println(i);
//             //return i;
//             }
//             //return -1;
//         }
//     }
//          public static void main(String[] args) {
//               int arr[] = {30, 58, 83, 85, 63, 74};
//               int x = 63;
//               search(arr,x);
              
//         //int result = search(arr,x);
//        // if(result==-1){
//        // System.out.print(" ");
//        // }
//        // System.out.println()
//          }
//        // System.out.println("Hello, World!"); 

// }




//Stering----





