import java.util.*;
public class Arrays{
    public static void main(String args[]){
    //   int marks[] = {97, 78, 89};
      //or  
        // int []marks = new int[3];
        // marks[0] = 97;
        // marks[1] = 78;
        // marks[2] = 89;

           // System.out.println(marks[0]);
           // System.out.println(marks[1]);
           // System.out.println(marks[2]);
    //or
    //    for(int i=0; i<marks.length; i++){
    //     System.out.println(marks[i]);
    //    }

       
//    Scanner sc = new Scanner(System.in);
//    int size = sc.nextInt();
//    int numbers[] = new int[size];
//    for(int i=0; i<size; i++){
//     numbers[i] = sc.nextInt();
//    }
//    for(int i=0; i<size; i++){
//     System.out.println(numbers[i]);
//    }

//* Take an array as input from the user. Search for a give number x and print the index at which it occurs.
//   linear search

// Scanner sc = new Scanner(System.in);
//    int size = sc.nextInt();
//    int numbers[] = new int[size];
//    for(int i=0; i<size; i++){
//     numbers[i] = sc.nextInt();
//    }
//    int x = sc.nextInt();
//    for(int i=0; i<size; i++){
//     if(numbers[i]==x)
//     System.out.println("x found at index : " + i);
//    }



// Scanner sc = new Scanner(System.in);
// int n = sc.nextInt();
// int num[] = new int[n];
// for (int i=0; i<n; i++){
//     num[i]=sc.nextInt();
// }
// int max = Integer.MIN_VALUE;
// int min = Integer.MAX_VALUE;

// for(int i=0; i<num.length; i++){
//     if(num[i]<min){
//         min = num[i];
//     }
//     if(num[i]>max){
//         max = num[i];
//     }
//    }
// System.out.println("minm: " + min);
// System.out.println("maxm: " + max);  



// Scanner sc = new Scanner(System.in);
// int size = sc.nextInt();
// int num[] = new int[size];
// for(int i =0;i<size;i++){
// num[i] = sc.nextInt();
// }
// boolean isAscending = true;
// for(int i =0; i<num.length-1;i++){
//     if(num[i]>num[i+1]){
//         isAscending = false;
//     }
// }
// if (isAscending){
//     System.out.println("this element is ascending");

// }else {
//     System.out.println(" this element not available is ascending");
// }


//## 2D arrays

    //  0 1 2 3 4
    // 0- - - - - 
    // 1- - - - -
    // 2- - - - -
    // 3- - - - -
    // 4- - - - -
 
//  type[][] arrayName = new type[rows][columns];

//   Scanner sc = new Scanner(System.in);
//   int rows = sc.nextInt();
//   int cols = sc.nextInt();
//   int[][] numbers = new int [rows][cols];

//   //input
//   for(int i=0; i<rows; i++){
//     for(int j=0; j<cols; j++){
//         numbers[i][j] = sc.nextInt();
//     }
//   }
//   //output
//   for(int i=0; i<rows; i++){
//     for(int j=0; j<cols; j++){
//        System.out.print(numbers[i][j] + " ");
//     }
//     System.out.println();
//   }
   

   // Take a matrix as input from the user. Search for a give number x and print the indices at which it occurs.

Scanner sc = new Scanner(System.in);
  int rows = sc.nextInt();
  int cols = sc.nextInt();
  int[][] numbers = new int [rows][cols];

  //input
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
        numbers[i][j] = sc.nextInt();
    }
  }
//   int x = sc.nextInt();
//   for(int i=0;i<rows; i++){
//     for(int j=0; j<cols; j++){
//         if(numbers[i][j] == x){
//             System.out.println(" x found at (" + i + ", " + j + ")");
//         }
//     }
//   }

// all element > element

//  int x = sc.nextInt();
//  for(int i=0;i<rows;i++){
//     for(int j=0; j<cols;j++){
//         if(numbers[i][j]>x){
//             System.out.println(" x found at (" + i + ", " + j + ")");
//         }else{
//             System.out.println("not any no (" + i + ", " + j + ")");
//         }
//     }
//  }



    }
}