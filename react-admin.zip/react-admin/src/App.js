// import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="app">
    
    <div>
    <h1>Hello friend</h1>
    
    </div>
      
    </div>
  );
}

export default App;
