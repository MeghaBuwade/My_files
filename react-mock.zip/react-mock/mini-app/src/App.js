// import React from 'react'
// import Ehook from './hookcomponent/Ehook';
// import Refhook from './hookcomponent/Refhook';
// import Shook from './hookcomponent/Shook';
// //import Hoc from './Hoc';
// export default function App() {
//   return (
//     <div>
//       <h1>Work in hooks</h1>
//       <Ehook/>
//       <Shook/>
//       <Refhook/>
//       {/* <Hoc/> */}
//     </div>
//   )
// }


import React from 'react'
import Prop from './Prop'
function App() {
  return (
    <div>
      hello
      <Prop/>
    </div>
  )
}

export default App
