import React, {useState, useEffect}from 'react'

function Ehook() {
    const [count, setCount]= useState(0);
    //const [increse, setIncrese]=useState(0);
    useEffect(() => {
          setTimeout(()=>{
            setCount((count)=>count+4);
            
          },1000);
          // setTimeout(()=>{
          //   setIncrese((increse)=>increse+2);
          // },1000);
          
    })//,[]  this is a empty brackets here
  return (
     
    <div>
      {/* <h2>{increse}+2</h2> */}
      <h1>{count}+4 </h1>
    </div>
  )
}

export default Ehook
