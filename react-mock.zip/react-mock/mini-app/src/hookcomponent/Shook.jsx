import React,{useState} from 'react'

function Shook() {
    const [car, setCar]=useState({
        brand:"alto",
        model:"Mustang",
        year:"2022",
        color:"pink"
    });

const updateColor = () => {
    setCar(previousState=>{
        return{  ...previousState, color:"red"}
    })
}

  return (
      
    <div><h1>{car.brand}</h1>
      <h2>{car.color}:
      {car.model}:
      {car.year}</h2>
      <button type='button' onClick={updateColor}>click</button>
    </div>
  )
}

export default Shook



