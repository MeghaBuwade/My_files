import React, {useState,useRef,useEffect} from 'react'

function Refhook() {
    //use for useState
    const [inpVal, setInpVal] = useState("");
    //use  for useRef
    const count = useRef(0);
     console.log(count);
    //use for useEffect
    useEffect(() => {
        count.current= count.current + 1;
        });
    
  return (
    <div>
        <h1>## useRef</h1>
        <input type= "text" value={inpVal} onChange={(e)=> setInpVal(e.target.value)}/>
      <h1>use refhook : {count.current}</h1>
    </div>
  )
}

export default Refhook
