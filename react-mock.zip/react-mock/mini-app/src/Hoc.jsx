import React from "react";
const printHello = ComposedComponent=> class Hoc extends React.Component{
    onClick(){
        console.log('hello');
    }



    render(){
        return(<ComposedComponent {...this.props} onClick={this.onClick}/>
)}}
const FirstComponent = props=>(
    <div onClick={props.onClick}>Hello , {props.name}! i am a FirstComponent</div>
);
const ExtendedComponent = printHello(FirstComponent);

