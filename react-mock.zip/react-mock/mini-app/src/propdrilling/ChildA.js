import React from 'react'
import ChildB from './ChildB'

function ChildA({firstName}) {
  return (
    <div>
      ChildA
      <ChildB firstName={firstName}/>
    </div>
  )
}

export default ChildA
