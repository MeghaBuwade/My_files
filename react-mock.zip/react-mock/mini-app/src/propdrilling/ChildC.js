import React from 'react'

function ChildC({firstName}) {
  return (
    <div>
      ChildC
      <h1>my name is {firstName}</h1>
    </div>
  )
}

export default ChildC;
