import React,{useState} from 'react'
import ChildA from './propdrilling/ChildA'

function Prop() {
const[name, setName] =useState("Megha Digarse")
  return (
    <div>
     <h1> heloo prop</h1>
     <ChildA firstName={name}/>
    </div>
  )
}

export default Prop
