const express = require("express");
const router = express.Router();
const Alien = require('../models/alien.js');

// GET all aliens
router.get('/', async (req, res) => {
    try {
        const aliens = await Alien.find();
        res.json(aliens);
    } catch (err) {
        res.send('Error: ' + err);
    }
});

// POST a new alien
router.post('/', async (req, res) => {
    console.log("POST request received");

    const alien = new Alien({
        name: req.body.name,
        tech: req.body.tech,
    });

    // try {
    //     const a1 = await alien.save();
    //     res.json(a1);
    // } catch (err) {
    //     res.status(500).send('Error: ' + err);
    // }
});

module.exports = router;
