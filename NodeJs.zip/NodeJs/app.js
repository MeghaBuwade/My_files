const express = require("express");
const mongoose = require("mongoose");
const url = "mongodb://localhost:27017/megha";
const app = express();
mongoose.connect(url, {useNewUrlParser:true})
const con = mongoose.connection;
con.on('open', () =>{
    console.log(`connected...`)}
)
const alienRouter = require('./routers/aliens');
app.use("/aliens", alienRouter);
app.listen(9000, () =>{
    console.log('server started')

})