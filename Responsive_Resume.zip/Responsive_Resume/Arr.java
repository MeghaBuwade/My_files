public class Arr{
    public static void main(String[] args) 
    {
        // for(int i=0; i<=10; i++)
        // {
        //  System.out.println(i);
        // }

// even num
    // for(int i=1; i<=10; i++){
    //     if(i%2==0){
    //         System.out.println(i);
    //     }
    // }

//Average
    // int array = {10, 20, 30, 40, 50};
    // int sum = "";
    // for(int i=0; i<array.length; i++){
    //   // [i % 5];
    // }

    // System.out.println(sum);
int[] arr ={2, 4, 1, 5, 7};
   for(int i=0; i<arr.length; i++){
    int smallest = arr[i];


    for(int j=i+1; j<arr.length; j++){
        if(arr[j]<arr[i]){
           smallest = arr[j]; 
           arr[i]=temp;
        }
    }
   
    System.out.print(arr[i] + " ");
   }

System.out.println();
 }
};