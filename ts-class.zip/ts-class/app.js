var a = 12;
