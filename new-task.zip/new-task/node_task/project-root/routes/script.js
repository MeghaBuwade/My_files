const express = require('express');
const router = express.Router();
const db = require('../db');

// POST
router.post('/', (req, res) => {
  const { patient_name, doctor_name, medicines, notes } = req.body;
  const sql = 'INSERT INTO script (patient_name, doctor_name, medicines, notes) VALUES (?, ?, ?, ?)';
  db.query(sql, [patient_name, doctor_name, medicines, notes], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: result.insertId, message: 'script saved' });
  });
});

// GET 
router.get('/', (req, res) => {
  const sql = 'SELECT * FROM script ORDER BY created_at DESC';
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// GET 
router.get('/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM script WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ message: 'script not found' });
    res.json(result[0]);
  });
});

module.exports = router;
